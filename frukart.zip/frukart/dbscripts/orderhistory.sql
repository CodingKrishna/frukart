INSERT INTO frukart.orderhistory (emailid,productid,productquantity,picname,price) VALUES 
('null','RASPBERRY','1','raspberry.jpg','96')
,('ravi1@gmail.com','STRAWBERRY','1','strwberry.jpg','123')
,('ravi1@gmail.com','FIG','1','fig.jpg','45')
,('ravi1@gmail.com','BUTTERFRUIT','1','butterfruit.jpg','30')
,('ravi1@gmail.com','RASPBERRY','1','raspberry.jpg','96')
,('ravi1@gmail.com','BLACKBERRY','1','blackberry.jpg','23')
,('ravi1@gmail.com','POMEOGRANAT','1','pomeo.jpg','100')
;