﻿INSERT INTO frukart.productdetails (fid,pic,pric,fname,about) VALUES 
('2','raspberry.jpg','96','RASPBERRY',NULL)
,('3','strwberry.jpg','123','STRAWBERRY',NULL)
,('4','fig.jpg','45','FIG',NULL)
,('5','butterfruit.jpg','30','BUTTERFRUIT',NULL)
,('6','blackberry.jpg','23','BLACKBERRY',NULL)
,('7','blackgrapes.jpg','45','BLACKGRAPES',NULL)
,('8','kiwi.jpg','78','KIWI',NULL)
,('9','apple.jpg','300','APPLE',NULL)
,('10','guava.jpg','90','GUAVA',NULL)
,('11','litche.jpg','40','LITCHE',NULL)
;
INSERT INTO frukart.productdetails (fid,pic,pric,fname,about) VALUES 
('12','orange.jpg','80','ORANGE',NULL)
,('13','pomeo.jpg','100','POMEOGRANAT',NULL)
,('14','banana.jpg','70','BANANA',NULL)
,('15','pear.jpg','85','PEAR',NULL)
,('1','pineapple.jpg','36','PINEAPPLE','The pineapple is a tropical plant with an edible multiple fruit consisting of coalesced berries, also called pineapples, and the most economically significant plant in the family Bromeliaceae')
;