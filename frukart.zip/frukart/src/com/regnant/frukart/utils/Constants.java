package com.regnant.frukart.utils;

public class Constants {
	
	public static final String HOME_PAGE = "home";
	public static final String PASSWORD = "password";
	public static final String EMAIL = "email";
	public static final String FRUITS_LIST = "fruitsList";
	public static final String DECREMENT_QNT = "subitem";
	public static final String INCREMENT_QNT = "additem";
	public static final String REMOVE_ITEM = "removeitem";
	public static final String ADD_PRODUCTS = "addproducts";
	public static final String ADD_TO_CART = "addtocart";
	public static final String TASK = "task";
	public static final String ID = "id";
	public static final long serialVersionUID = 1L;
}
