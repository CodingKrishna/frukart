package com.regnant.frukart.servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.regnant.email.EmailUtils;
import com.regnant.frukart.dao.AuthDAO;

/**
 * Servlet implementation class ForgotPassword
 */
@WebServlet("/Forgot")
public class ForgotPasswordServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ForgotPasswordServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		String task = request.getParameter("task");
		System.out.println(task);
		if (task.equals("login")) {
			RequestDispatcher rd = request.getRequestDispatcher("/view/forgot.html");
			rd.forward(request, response);
		} else if (task.equals("pass")) {
			String DBemail = request.getParameter("mail");

			System.out.println(DBemail);
			String userEmail;
			try {
				userEmail = AuthDAO.getMailID(DBemail);

				if (DBemail.equals(userEmail) || userEmail != null) {
					System.out.println(DBemail + " " + userEmail);
					String pas = AuthDAO.getForgottenPassword(userEmail);
					System.out.println(pas);
					EmailUtils.sendMail(DBemail);

					System.out.print("Password sent to your Mail ");
				} else {
					System.out.print("Check your mail ID");
				}
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block

				e.printStackTrace();
			}

		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
//
}
