package com.regnant.frukart.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.JsonObject;
import com.regnant.frukart.dao.searchDAO;

/**
 * Servlet implementation class searchservlet
 */
@WebServlet("/searchservlet")
public class searchservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public searchservlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());

		String search = request.getParameter("search");
//		response.setContentType("text/html");

		if (!((search.trim()).equals(" "))) {

			try {
				List<String> searchlist = searchDAO.getsearchdata();
				List<JsonObject> jsonli = new ArrayList<>();
//				JsonArray json_search_arr =new JsonArray();
				for (String fname : searchlist) {
					JsonObject obj = new JsonObject();
					obj.addProperty("fname", fname);
//				json_search_arr.add(obj);
					jsonli.add(obj);
				}

				response.getWriter().write(jsonli.toString());

				/*
				 * JsonObject responseDetailsJson = new JsonObject(); JsonArray jsonArray = new
				 * JsonArray();
				 * 
				 * List<String> searchlist = new Vector<Product>(cartMap.keySet().size());
				 * for(Product p : cartMap.keySet()) { cartList.add(p); JSONObject
				 * formDetailsJson = new JSONObject(); formDetailsJson.put("id", "1");
				 * formDetailsJson.put("name", "name1"); jsonArray.add(formDetailsJson); }
				 * responseDetailsJson.put("forms", jsonArray);//Here you can see the data in
				 * json format
				 * 
				 * return cartList;
				 * 
				 * 
				 * 
				 */

			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} else
			response.getWriter().write("");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
