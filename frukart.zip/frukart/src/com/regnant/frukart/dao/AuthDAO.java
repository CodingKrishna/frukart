package com.regnant.frukart.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

import javax.print.attribute.HashAttributeSet;

public class AuthDAO {

	public static boolean signIn(String email, String password) throws ClassNotFoundException, SQLException {
		Connection con = DbConnection.getConnection();
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery("select \"password\" from frukart.usersdata where email='" + email + "';");
		System.out.println(password + email);
		String p = "";
		while (rs.next()) {
			p = rs.getString(1);
		}
		System.out.println(p);
		if (p.equals(password)) {
			return true;
		} else {
			return false;
		}
	}

	public static boolean getMailID(String mail) throws ClassNotFoundException, SQLException {
		Connection con = DbConnection.getConnection();
		PreparedStatement stmt = con.prepareStatement("select email from frukart.usersdata where email = ?");
		stmt.setString(1, mail);
		String mailID = null;
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			mailID = rs.getString(1);
		}
		if (mailID.equals(mail)) {
			return true;
		} else {
			return false;
		}

	}

	public static String getForgottenPassword(String name) throws ClassNotFoundException, SQLException {
		Connection con = DbConnection.getConnection();
		PreparedStatement stmt = con.prepareStatement("select password from frukart.usersdata where email = ?");
		stmt.setString(1, name);
		String password = null;
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			password = rs.getString(1);
		}
		return password;
	}

	public static Map<String, String> getUserDetails(String mail) throws ClassNotFoundException, SQLException {
		Map<String, String> userDetails = new HashMap<String, String>();
		Connection con = DbConnection.getConnection();
		PreparedStatement stmt = con.prepareStatement("select username,email,mobile,address from frukart.usersdata where email = ?");
		stmt.setString(1, mail);
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			userDetails.put("username", rs.getString(1));
			userDetails.put("email", rs.getString(2));
			userDetails.put("mobile", rs.getString(3));
			userDetails.put("address", rs.getString(4));
		}
		return userDetails;
	}

	
	  public static void updateUserDetails(String name, String mail, String mobile,String address)
	  throws ClassNotFoundException, SQLException { 
		  System.out.println(name+" "+mail+" "+mobile+" "+address);
		  Connection con =DbConnection.getConnection(); 
		  PreparedStatement stmt = con.prepareStatement("select username,mobile,address from frukart.usersdata where email =?;");
		  stmt.setString(1,mail);
		  ResultSet rs = stmt.executeQuery(); 
		  String username = ""; 
		  String mob = ""; 
		  String dbaddress="";
		  while (rs.next()) {
			  username = rs.getString(1); 
			  mob = rs.getString(2);
			  dbaddress=rs.getString(3);
			  } 
		  System.out.println(username+" "+mob+" "+dbaddress);
		  if(!username.equals(name)) {
		  stmt = con.prepareStatement("UPDATE frukart.usersdata SET username= ? where email = ? ;");
		  stmt.setString(1, name);
			stmt.setString(2, mail);
			stmt.executeUpdate();
		  } 
		  if (!mob.equals(mobile)) {
			  stmt = con.prepareStatement("UPDATE frukart.usersdata SET mobile= ? where email = ? ;");
			  stmt.setString(1, mobile);
			  stmt.setString(2, mail);
			  stmt.executeUpdate();
			  } 
		  if (!dbaddress.equals(address)) {
			  stmt = con.prepareStatement("UPDATE frukart.usersdata SET address= ? where email = ? ;");
			  stmt.setString(1, address);
			  stmt.setString(2, mail);
			  stmt.executeUpdate();
			  } 
		  }
	 
	public static void updateEmail(String email, String MainEmail) throws ClassNotFoundException, SQLException {
		Connection con = DbConnection.getConnection();
		PreparedStatement stmt = con.prepareStatement("UPDATE frukart.usersdata SET email= ? where email = ? ;");
		stmt.setString(1, email);
		stmt.setString(2, MainEmail);
		stmt.executeUpdate();
	}
/*
	public static void updateUserDetails(String name, String mail, String mobile)
			throws ClassNotFoundException, SQLException {
		Connection con = DbConnection.getConnection();
		PreparedStatement stmt = con.prepareStatement("UPDATE frukart.usersdata SET username=?, email=?, mobile=? where email=?;");
		stmt.setString(1, name);
		stmt.setString(2, mail);
		stmt.setString(3, mobile);
		stmt.setString(4, mail);
		stmt.executeUpdate();

	}*/

}
