package com.regnant.frukart.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class OrderDAO {

	public static int placeOrder(String email, String productname, String quantity, String picname, String price)
			throws ClassNotFoundException, SQLException {
		Connection con = DbConnection.getConnection();
		String sqlquery = "INSERT INTO frukart.orderhistory VALUES('" + email + "','" + productname + "','" + quantity
				+ "','" + picname + "','" + price + "');";
		PreparedStatement pstmt = con.prepareStatement(sqlquery);
		return pstmt.executeUpdate();
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })

	public static Set<Map<String, String>> getcart(String email) throws ClassNotFoundException, SQLException {

		Set<Map<String, String>> li = new HashSet<>();

		Connection con = DbConnection.getConnection();
		PreparedStatement stmt = con.prepareStatement(
				"select productid, productquantity, picname, price from frukart.orderhistory where emailid = ?;");
		stmt.setString(1, email);
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			String productid = rs.getString(1);

			String productquantity = rs.getString(2);

			String productImg = rs.getString(3);

			String price = rs.getString(4);
			Map<String, String> fruit = new HashMap();

			fruit.put("productname", productid);

			fruit.put("productquantity", productquantity);

			fruit.put("productImg", productImg);

			fruit.put("price", price);

			li.add(fruit);
		}

		return li;

	}

}
