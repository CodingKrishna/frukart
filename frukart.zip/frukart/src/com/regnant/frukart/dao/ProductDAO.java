package com.regnant.frukart.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.EmptyStackException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.regnant.frukart.beans.ProductBean;

public class ProductDAO {

	public static List<ProductBean> getProducts() throws ClassNotFoundException, SQLException {
		Connection con = DbConnection.getConnection();
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery("select * from frukart.productdetails");
		List<ProductBean> fruits = new ArrayList<>();
		while (rs.next()) {
			String fid = rs.getString(1);
			String pic = rs.getString(2);
			String price = rs.getString(3);
			String fname = rs.getString(4);
			String specfication = rs.getString(5);
			
			ProductBean productBean = new ProductBean(fid,fname,specfication,price,pic);
			fruits.add(productBean);
		}
		return fruits;
	}

	public static Map<String, String> getProductById(String id) throws ClassNotFoundException, SQLException {
		Connection con = DbConnection.getConnection();
		PreparedStatement stmt = con.prepareStatement("select * from frukart.productdetails where fid=?");
		stmt.setString(1, id);
		ResultSet rs = stmt.executeQuery();
		Map<String, String> fruit = new HashMap<>();
		while (rs.next()) {
			String fid = rs.getString(1);
			String pic = rs.getString(2);
			String price = rs.getString(3);
			String fname = rs.getString(4);
			String specfication = rs.getString(5);

			fruit.put("id", fid);
			fruit.put("name", fname);
			fruit.put("pic", pic);
			fruit.put("price", price);
			fruit.put("about", specfication);
		}
		return fruit;
	}
	public static void anonymousDelete(String email) throws ClassNotFoundException, SQLException {
		Connection con = DbConnection.getConnection();
		String sql = "DELETE FROM frukart.anonymous WHERE email='"+email+"';";
		Statement s = con.createStatement();
		s.executeUpdate(sql);
	}
	public static void anonymous(Set<Map<String, String>> cart,String email) throws SQLException, ClassNotFoundException,EmptyStackException {
		Connection con = DbConnection.getConnection();
		List<String> s = new ArrayList<>();
		for(Map<String, String> product:cart) {
			String tname = product.get("name");
			if(!s.contains(tname)) {
				s.add(tname);
			PreparedStatement stmt = con.prepareStatement("INSERT INTO frukart.anonymous VALUES(?, ?, ?, ?,?,?);");
			stmt.setString(1, product.get("id"));
			stmt.setString(2, product.get("name"));
			stmt.setString(3, product.get("pic"));
			stmt.setString(4, product.get("price"));
			stmt.setString(5, email);
			stmt.setString(6, product.get("count"));
			stmt.executeUpdate();
			}
		}
	}
	
	public static Set<Map<String, String>> getanonymous(String email) throws SQLException, ClassNotFoundException {
			Connection con = DbConnection.getConnection();
			PreparedStatement stmt = con.prepareStatement("SELECT productid, name, pic, price,\"count\" FROM frukart.anonymous where email = ? ;");
			stmt.setString(1, email);
			ResultSet rs = stmt.executeQuery();
			Set<Map<String, String>> fruits = new HashSet<>();
			while (rs.next()) {
				Map<String,String> product = new HashMap<>();
				String productid = rs.getString(1);
				String name = rs.getString(2);
				String pic = rs.getString(3);
				String price = rs.getString(4);
				String count=rs.getString(5);
				product.put("productid", productid);
				product.put("name", name);
				product.put("pic", pic);
				product.put("price", price);
				product.put("count", count);
				fruits.add(product);
			}
			System.out.println(fruits);
			return fruits;
			
	}

}
