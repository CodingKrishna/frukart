package com.regnant.frukart.dao;
import com.regnant.frukart.beans.ProfileBean;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProfileDAO {

	public static List<ProfileBean> profiledetails(String email) throws ClassNotFoundException, SQLException {
		Connection con = DbConnection.getConnection();
		String sql = "select * from frukart.usersdata where email= ?;";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, email);
		List<ProfileBean> profilelist = new ArrayList<>();
		ResultSet rs = pstmt.executeQuery();
		while (rs.next()) {
			String username = rs.getString(1);
			String dbemail = rs.getString(3);
			String dbphone = rs.getString(4);
			profilelist.add(new ProfileBean(username, dbemail, dbphone));
		}
		con.close();
		return profilelist;
	}
	public static void chnge_profile_dat(String username, String email, String phone, String address)
			throws ClassNotFoundException, SQLException {
		Connection con = DbConnection.getConnection();
		PreparedStatement pstmt = con.prepareStatement("UPDATE frukart.usersdata SET username=?, email=?, phone=?, address=? where email='" + email + "';");
		pstmt.setString(1, username);
		pstmt.setString(2, email);
		pstmt.setString(3, phone);
		pstmt.setString(4, address);
		pstmt.executeQuery();
		con.close();
	}

}
